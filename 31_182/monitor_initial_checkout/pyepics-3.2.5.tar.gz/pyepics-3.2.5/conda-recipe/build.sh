#!/bin/bash

$PYTHON setup.py install

# Add more build steps here, if they are necessary.
